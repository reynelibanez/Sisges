import { useState } from "react";
import ProductosPanel from "./ProductosPanel";
import AlmacenesPanel from "./AlmacenesPanel";
import AreasPanel from "./AreasPanel";
import UnidadesPanel from "./UnidadesPanel";
import TiposPanel from "./TiposPanel";
import MonedasPanel from "./MonedasPanel";
import RecepcionesPanel from "./RecepcionesPanel";
import TransferenciasPanel from "./TransferenciasPanel";
import BajasPanel from "./BajasPanel";
import MotivosBajaPanel from "./MotivosBajaPanel";
import ExistenciasPanel from "./ExistenciasPanel";
import VentasPanel from "./VentasPanel";

// Sub-módulos del tab "Inventario". El módulo "Caja" del sistema de
// escritorio se unificó aquí como "Ventas" (ex vales de salida + cobro),
// porque en el fondo usa las mismas tablas que Inventario.
const SECCIONES = [
  { key: "ventas", label: "Ventas (Caja)", Comp: VentasPanel },
  { key: "existencias", label: "Existencias", Comp: ExistenciasPanel },
  { key: "productos", label: "Productos", Comp: ProductosPanel },
  { key: "recepciones", label: "Recepciones", Comp: RecepcionesPanel },
  { key: "transferencias", label: "Transferencias", Comp: TransferenciasPanel },
  { key: "bajas", label: "Bajas", Comp: BajasPanel },
  { key: "almacenes", label: "Almacenes", Comp: AlmacenesPanel },
  { key: "areas", label: "Áreas", Comp: AreasPanel },
  { key: "unidades", label: "U. de Medida", Comp: UnidadesPanel },
  { key: "tipos", label: "Tipos de Producto", Comp: TiposPanel },
  { key: "motivos", label: "Motivos de Baja", Comp: MotivosBajaPanel },
  { key: "monedas", label: "Monedas", Comp: MonedasPanel },
] as const;

export default function InventarioModule() {
  const [activa, setActiva] = useState<(typeof SECCIONES)[number]["key"]>("ventas");
  const Seccion = SECCIONES.find((s) => s.key === activa)?.Comp ?? VentasPanel;

  return (
    <div>
      <div className="sub-tabs">
        {SECCIONES.map((s) => (
          <button key={s.key} className={activa === s.key ? "active" : ""} onClick={() => setActiva(s.key)}>
            {s.label}
          </button>
        ))}
      </div>
      <Seccion />
    </div>
  );
}
