import { useState } from "react";
import DataGrid from "@/components/DataGrid";
import Modal from "@/components/Modal";
import { api, useList } from "@/lib/useApi";
import { exportCsv } from "@/lib/csv";

interface Linea {
  idproducto: string;
  idarea: string;
  cantidad: string;
  preciocosto: string;
  pventa: string;
}
interface Pago {
  idmoneda: string;
  tc: string;
  importe: string;
}

const lineaVacia: Linea = { idproducto: "", idarea: "", cantidad: "1", preciocosto: "0", pventa: "0" };
const pagoVacio: Pago = { idmoneda: "", tc: "1", importe: "0" };

/**
 * Ventas — este panel reemplaza al antiguo tab "Caja" del sistema de
 * escritorio (Escoger punto de venta + vales de salida + pagos en varias
 * monedas), unificado aquí dentro de Inventario porque comparten la misma
 * base de datos (almacenes, productos, existencias).
 */
export default function VentasPanel() {
  const { data, loading, error, reload, setData } = useList("/api/inventario/ventas");
  const { data: almacenes } = useList("/api/inventario/almacenes");
  const { data: areas } = useList("/api/inventario/areas");
  const { data: productos } = useList("/api/inventario/productos");
  const { data: monedas } = useList("/api/inventario/monedas");

  const [showForm, setShowForm] = useState(false);
  const [idalmacen, setIdalmacen] = useState("");
  const [nota, setNota] = useState("");
  const [lineas, setLineas] = useState<Linea[]>([{ ...lineaVacia }]);
  const [pagos, setPagos] = useState<Pago[]>([{ ...pagoVacio }]);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const puntosVenta = almacenes.filter((a: any) => a.pventa);

  function openNew() {
    setIdalmacen("");
    setNota("");
    setLineas([{ ...lineaVacia }]);
    setPagos([{ ...pagoVacio }]);
    setFormError(null);
    setShowForm(true);
  }

  function actualizarLinea(i: number, campo: keyof Linea, valor: string) {
    setLineas((prev) => {
      const next = prev.map((l, idx) => (idx === i ? { ...l, [campo]: valor } : l));
      if (campo === "idproducto") {
        const producto = productos.find((p: any) => String(p.idproducto) === valor);
        if (producto) {
          next[i].preciocosto = String(producto.pcosto);
          next[i].pventa = String(producto.pventa);
        }
      }
      return next;
    });
  }

  function actualizarPago(i: number, campo: keyof Pago, valor: string) {
    setPagos((prev) => prev.map((p, idx) => (idx === i ? { ...p, [campo]: valor } : p)));
  }

  const totalVenta = lineas.reduce((acc, l) => acc + (Number(l.cantidad) || 0) * (Number(l.pventa) || 0), 0);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFormError(null);
    try {
      await api.post("/api/inventario/ventas", {
        idalmacen: Number(idalmacen),
        nota,
        detalle: lineas
          .filter((l) => l.idproducto)
          .map((l) => ({
            idproducto: Number(l.idproducto),
            idarea: l.idarea ? Number(l.idarea) : null,
            cantidad: Number(l.cantidad),
            preciocosto: Number(l.preciocosto),
            pventa: Number(l.pventa),
          })),
        pagos: pagos
          .filter((p) => p.idmoneda)
          .map((p) => ({
            idmoneda: Number(p.idmoneda),
            tc: Number(p.tc),
            importe: Number(p.importe),
          })),
      });
      setShowForm(false);
      await reload();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "No se pudo guardar");
    } finally {
      setSaving(false);
    }
  }

  async function handleAnular(row: any) {
    if (!confirm(`¿Anular la venta No. ${row.noconsecutivo}? Esto devuelve el stock al almacén.`)) return;
    try {
      const actualizado = await api.post(`/api/inventario/ventas/${row.idvalesalida}/anular`, {});
      setData((prev) => prev.map((r) => (r.idvalesalida === row.idvalesalida ? { ...r, anulada: actualizado.anulada } : r)));
    } catch (e) {
      alert(e instanceof Error ? e.message : "No se pudo anular");
    }
  }

  const almacenNombre = (id: number) => almacenes.find((a: any) => a.idalmacen === id)?.almacen ?? id;
  const totalDe = (r: any) => (r.detalle ?? []).reduce((acc: number, l: any) => acc + Number(l.cantidad) * Number(l.pventa), 0);

  return (
    <div className="panel">
      <div className="panel-toolbar">
        <h2>Ventas (Caja)</h2>
        <button className="btn btn-secondary" onClick={() => exportCsv("ventas.csv", data)}>
          Exportar CSV
        </button>
      </div>

      {error && <div className="error-box" style={{ margin: 12 }}>{error}</div>}
      {puntosVenta.length === 0 && !loading && (
        <div className="error-box" style={{ margin: 12 }}>
          No hay ningún almacén marcado como "Punto de venta". Ve a Almacenes y marca uno.
        </div>
      )}

      <DataGrid
        rows={data}
        loading={loading}
        rowKey={(r: any) => r.idvalesalida}
        onNew={puntosVenta.length ? openNew : undefined}
        emptyLabel="No hay ventas registradas"
        contextActions={[
          {
            label: "Anular",
            danger: true,
            show: (r: any) => !r.anulada,
            onClick: handleAnular,
          },
        ]}
        columns={[
          { key: "noconsecutivo", label: "No." },
          { key: "fecha", label: "Fecha", render: (r: any) => new Date(r.fecha).toLocaleString() },
          { key: "idalmacen", label: "Punto de venta", render: (r: any) => almacenNombre(r.idalmacen) },
          { key: "total", label: "Total", render: (r: any) => totalDe(r).toFixed(2) },
          {
            key: "anulada",
            label: "Estado",
            render: (r: any) =>
              r.anulada ? <span className="badge badge-off">Anulada</span> : <span className="badge badge-ok">Activa</span>,
          },
        ]}
      />

      {showForm && (
        <Modal title="Nueva venta" onClose={() => setShowForm(false)} wide>
          <form onSubmit={handleSave}>
            {formError && <div className="error-box">{formError}</div>}
            <div className="form-grid">
              <div className="field">
                <label>Punto de venta</label>
                <select required value={idalmacen} onChange={(e) => setIdalmacen(e.target.value)}>
                  <option value="">Selecciona…</option>
                  {puntosVenta.map((a: any) => (
                    <option key={a.idalmacen} value={a.idalmacen}>
                      {a.almacen}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Nota</label>
                <input value={nota} onChange={(e) => setNota(e.target.value)} />
              </div>
            </div>

            <h4 style={{ margin: "16px 0 8px" }}>Productos</h4>
            {lineas.map((l, i) => (
              <div className="linea-row" key={i}>
                <select value={l.idproducto} onChange={(e) => actualizarLinea(i, "idproducto", e.target.value)}>
                  <option value="">Producto…</option>
                  {productos.map((p: any) => (
                    <option key={p.idproducto} value={p.idproducto}>
                      {p.producto}
                    </option>
                  ))}
                </select>
                <select value={l.idarea} onChange={(e) => actualizarLinea(i, "idarea", e.target.value)}>
                  <option value="">Área…</option>
                  {areas.map((a: any) => (
                    <option key={a.idarea} value={a.idarea}>
                      {a.area}
                    </option>
                  ))}
                </select>
                <input type="number" min="0" step="0.01" placeholder="Cant." value={l.cantidad} onChange={(e) => actualizarLinea(i, "cantidad", e.target.value)} />
                <input type="number" min="0" step="0.01" placeholder="Precio" value={l.pventa} onChange={(e) => actualizarLinea(i, "pventa", e.target.value)} />
                <button type="button" className="btn btn-secondary" onClick={() => setLineas((prev) => prev.filter((_, idx) => idx !== i))}>
                  ✕
                </button>
              </div>
            ))}
            <button type="button" className="btn btn-secondary" onClick={() => setLineas((prev) => [...prev, { ...lineaVacia }])}>
              + Agregar línea
            </button>
            <div className="total-line">Total: {totalVenta.toFixed(2)}</div>

            <h4 style={{ margin: "16px 0 8px" }}>Pago (puede ser en varias monedas)</h4>
            {pagos.map((p, i) => (
              <div className="linea-row" key={i} style={{ gridTemplateColumns: "1fr 1fr 1fr auto" }}>
                <select value={p.idmoneda} onChange={(e) => actualizarPago(i, "idmoneda", e.target.value)}>
                  <option value="">Moneda…</option>
                  {monedas.map((m: any) => (
                    <option key={m.idmoneda} value={m.idmoneda}>
                      {m.moneda}
                    </option>
                  ))}
                </select>
                <input type="number" min="0" step="0.0001" placeholder="Tasa cambio" value={p.tc} onChange={(e) => actualizarPago(i, "tc", e.target.value)} />
                <input type="number" min="0" step="0.01" placeholder="Importe" value={p.importe} onChange={(e) => actualizarPago(i, "importe", e.target.value)} />
                <button type="button" className="btn btn-secondary" onClick={() => setPagos((prev) => prev.filter((_, idx) => idx !== i))}>
                  ✕
                </button>
              </div>
            ))}
            <button type="button" className="btn btn-secondary" onClick={() => setPagos((prev) => [...prev, { ...pagoVacio }])}>
              + Agregar forma de pago
            </button>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setShowForm(false)}>
                Cancelar
              </button>
              <button type="submit" className="btn btn-primary" disabled={saving} style={{ width: "auto" }}>
                {saving ? "Guardando…" : "Cobrar"}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
