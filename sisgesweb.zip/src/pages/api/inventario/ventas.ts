import type { APIRoute } from "astro";
import { z } from "zod";
import { eq, max } from "drizzle-orm";
import { db } from "@/db/client";
import { ilValesSalida, ilValesSalidaDetalle, ilValesMonedas } from "@/db/schema";
import { json, requireUser, isResponse } from "@/lib/api";
import { ajustarExistencia } from "@/lib/existencias";

export const prerender = false;

const detalleSchema = z.object({
  idproducto: z.coerce.number().int(),
  idarea: z.coerce.number().int().optional().nullable(),
  cantidad: z.coerce.number().positive(),
  preciocosto: z.coerce.number().min(0),
  pventa: z.coerce.number().min(0),
});

const pagoSchema = z.object({
  idmoneda: z.coerce.number().int(),
  tc: z.coerce.number().positive().default(1),
  importe: z.coerce.number().positive(),
});

// Esta es la "venta" (antes vale de salida + módulo Caja, ahora unificados
// dentro de Inventario). idalmacen es el punto de venta desde el que se vende.
const ventaSchema = z.object({
  idalmacen: z.coerce.number().int(),
  nota: z.string().optional().nullable(),
  detalle: z.array(detalleSchema).min(1, "Agrega al menos un producto"),
  pagos: z.array(pagoSchema).min(1, "Agrega al menos una forma de pago"),
});

export const GET: APIRoute = async ({ locals }) => {
  const user = requireUser(locals, "caja");
  if (isResponse(user)) return user;

  const rows = await db.query.ilValesSalida.findMany({
    where: (t, { eq }) => eq(t.idempresa, user.idempresa),
    with: { detalle: true, pagos: true },
    orderBy: (t, { desc }) => desc(t.fecha),
  });

  return json(rows);
};

export const POST: APIRoute = async ({ request, locals }) => {
  const user = requireUser(locals, "caja");
  if (isResponse(user)) return user;

  const parsed = ventaSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return json({ error: parsed.error.flatten() }, 400);
  const { idalmacen, nota, detalle, pagos } = parsed.data;

  const totalDetalle = detalle.reduce((acc, l) => acc + l.cantidad * l.pventa, 0);
  const totalPagos = pagos.reduce((acc, p) => acc + p.importe * p.tc, 0);
  if (Math.abs(totalDetalle - totalPagos) > 0.5) {
    return json(
      { error: `El total de la venta (${totalDetalle.toFixed(2)}) no coincide con el pago (${totalPagos.toFixed(2)})` },
      400
    );
  }

  const row = await db.transaction(async (tx) => {
    const [{ ultimo }] = await tx
      .select({ ultimo: max(ilValesSalida.noconsecutivo) })
      .from(ilValesSalida)
      .where(eq(ilValesSalida.idempresa, user.idempresa));

    const [venta] = await tx
      .insert(ilValesSalida)
      .values({
        idempresa: user.idempresa,
        noconsecutivo: (ultimo ?? 0) + 1,
        idalmacen,
        nota,
        creadoPor: user.idusuario,
      })
      .returning();

    for (const linea of detalle) {
      await tx.insert(ilValesSalidaDetalle).values({
        idvalesalida: venta.idvalesalida,
        idproducto: linea.idproducto,
        idarea: linea.idarea ?? null,
        preciocosto: String(linea.preciocosto),
        pventa: String(linea.pventa),
        cantidad: String(linea.cantidad),
      });

      // Una venta saca mercancía del punto de venta: baja el saldo.
      await ajustarExistencia(tx, {
        idempresa: user.idempresa,
        idalmacen,
        idproducto: linea.idproducto,
        delta: -linea.cantidad,
      });
    }

    for (const pago of pagos) {
      await tx.insert(ilValesMonedas).values({
        idvalesalida: venta.idvalesalida,
        idmoneda: pago.idmoneda,
        tc: String(pago.tc),
        importe: String(pago.importe),
      });
    }

    return venta;
  });

  return json(row, 201);
};
