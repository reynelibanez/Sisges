import { useState } from "react";
import InventarioModule from "./inventario/InventarioModule";

interface DashboardAppProps {
  nombreCompleto: string;
  empresaNombre: string;
}

// Mismo espíritu que el menú superior por tabs del sistema de escritorio:
// cada tab de arriba es un módulo completo. Por ahora solo Inventario está
// implementado; el resto queda listado (deshabilitado) para ir migrando
// módulo por módulo más adelante.
const MODULOS = [
  { key: "inventario", label: "Inventario", enabled: true },
  { key: "contabilidad", label: "Contabilidad", enabled: false },
  { key: "personal", label: "Personal", enabled: false },
  { key: "finanzas", label: "Finanzas", enabled: false },
  { key: "facturas", label: "Facturación", enabled: false },
] as const;

export default function DashboardApp({ nombreCompleto, empresaNombre }: DashboardAppProps) {
  const [moduloActivo, setModuloActivo] = useState("inventario");

  async function cerrarSesion() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    window.location.href = "/login";
  }

  return (
    <div className="app-shell">
      <div className="top-bar">
        <div className="brand">SisGes</div>
        <div className="top-tabs">
          {MODULOS.map((m) => (
            <button
              key={m.key}
              className={[moduloActivo === m.key ? "active" : "", m.enabled ? "" : "disabled"].join(" ")}
              disabled={!m.enabled}
              title={m.enabled ? undefined : "Próximamente"}
              onClick={() => setModuloActivo(m.key)}
            >
              {m.label}
            </button>
          ))}
        </div>
        <div className="user-menu">
          <span>
            {nombreCompleto} — {empresaNombre}
          </span>
          <button onClick={cerrarSesion}>Cerrar sesión</button>
        </div>
      </div>

      <div className="module-body">{moduloActivo === "inventario" && <InventarioModule />}</div>
    </div>
  );
}
