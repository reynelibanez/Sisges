import { useState } from "react";

export interface ColumnDef<T> {
  key: string;
  label: string;
  render?: (row: T) => React.ReactNode;
}

interface ContextAction<T> {
  label: string;
  onClick: (row: T) => void;
  danger?: boolean;
  /** Si devuelve false, la opción no aparece para esa fila. */
  show?: (row: T) => boolean;
}

interface DataGridProps<T> {
  columns: ColumnDef<T>[];
  rows: T[];
  rowKey: (row: T) => string | number;
  loading?: boolean;
  emptyLabel?: string;
  onNew?: () => void;
  onRowDoubleClick?: (row: T) => void;
  /** Opciones del clic derecho, igual que en el sistema de escritorio
   * (Nuevo / Modificar / Eliminar / Exportar...). */
  contextActions?: ContextAction<T>[];
}

/**
 * Grid genérico con clic derecho, replicando el patrón del sistema de
 * escritorio: cada grid tiene su propio menú contextual con las acciones
 * que se pueden ejecutar sobre la fila seleccionada.
 */
export default function DataGrid<T>({
  columns,
  rows,
  rowKey,
  loading,
  emptyLabel = "Sin datos",
  onNew,
  onRowDoubleClick,
  contextActions = [],
}: DataGridProps<T>) {
  const [menu, setMenu] = useState<{ x: number; y: number; row: T } | null>(null);

  function handleContextMenu(e: React.MouseEvent, row: T) {
    e.preventDefault();
    setMenu({ x: e.clientX, y: e.clientY, row });
  }

  function closeMenu() {
    setMenu(null);
  }

  return (
    <div onClick={closeMenu}>
      <div className="grid-wrap">
        <table className="data-grid">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col.key}>{col.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={rowKey(row)}
                onContextMenu={(e) => handleContextMenu(e, row)}
                onDoubleClick={() => onRowDoubleClick?.(row)}
              >
                {columns.map((col) => (
                  <td key={col.key}>{col.render ? col.render(row) : String((row as any)[col.key] ?? "")}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && rows.length === 0 && <div className="empty-state">{emptyLabel}</div>}
        {loading && <div className="empty-state">Cargando…</div>}
      </div>

      {menu && (
        <div className="context-menu" style={{ left: menu.x, top: menu.y }} onClick={(e) => e.stopPropagation()}>
          {onNew && (
            <button
              onClick={() => {
                onNew();
                closeMenu();
              }}
            >
              Nuevo
            </button>
          )}
          {contextActions
            .filter((a) => !a.show || a.show(menu.row))
            .map((action) => (
              <button
                key={action.label}
                className={action.danger ? "danger" : ""}
                onClick={() => {
                  action.onClick(menu.row);
                  closeMenu();
                }}
              >
                {action.label}
              </button>
            ))}
        </div>
      )}
    </div>
  );
}
