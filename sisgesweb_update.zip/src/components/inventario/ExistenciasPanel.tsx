import DataGrid from "@/components/DataGrid";
import { useList } from "@/lib/useApi";
import { exportCsv } from "@/lib/csv";

export default function ExistenciasPanel() {
  const { data, loading, error } = useList("/api/inventario/existencias");

  return (
    <div className="panel">
      <div className="panel-toolbar">
        <h2>Existencias</h2>
        <button className="btn btn-secondary" onClick={() => exportCsv("existencias.csv", data)}>
          Exportar CSV
        </button>
      </div>

      {error && <div className="error-box" style={{ margin: 12 }}>{error}</div>}

      <DataGrid
        rows={data}
        loading={loading}
        rowKey={(r: any) => r.idexistencia}
        emptyLabel="No hay existencias registradas"
        columns={[
          { key: "almacen", label: "Almacén" },
          { key: "producto", label: "Producto" },
          { key: "referencia", label: "Referencia" },
          { key: "saldo", label: "Saldo", render: (r: any) => Number(r.saldo).toFixed(2) },
        ]}
      />
    </div>
  );
}
