import { useState } from "react";
import DataGrid from "@/components/DataGrid";
import Modal from "@/components/Modal";
import { api, useList } from "@/lib/useApi";
import { exportCsv } from "@/lib/csv";

interface Linea {
  idproducto: string;
  cantidad: string;
  pcosto: string;
  pventa: string;
}

const lineaVacia: Linea = { idproducto: "", cantidad: "1", pcosto: "0", pventa: "0" };

export default function RecepcionesPanel() {
  const { data, loading, error, reload } = useList("/api/inventario/recepciones");
  const { data: almacenes } = useList("/api/inventario/almacenes");
  const { data: productos } = useList("/api/inventario/productos");

  const [showForm, setShowForm] = useState(false);
  const [idalmacen, setIdalmacen] = useState("");
  const [entregadapor, setEntregadapor] = useState("");
  const [nota, setNota] = useState("");
  const [lineas, setLineas] = useState<Linea[]>([{ ...lineaVacia }]);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  function openNew() {
    setIdalmacen("");
    setEntregadapor("");
    setNota("");
    setLineas([{ ...lineaVacia }]);
    setFormError(null);
    setShowForm(true);
  }

  function actualizarLinea(i: number, campo: keyof Linea, valor: string) {
    setLineas((prev) => prev.map((l, idx) => (idx === i ? { ...l, [campo]: valor } : l)));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFormError(null);
    try {
      await api.post("/api/inventario/recepciones", {
        idalmacen: Number(idalmacen),
        entregadapor,
        nota,
        detalle: lineas
          .filter((l) => l.idproducto)
          .map((l) => ({
            idproducto: Number(l.idproducto),
            cantidad: Number(l.cantidad),
            pcosto: Number(l.pcosto),
            pventa: Number(l.pventa),
          })),
      });
      setShowForm(false);
      await reload();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "No se pudo guardar");
    } finally {
      setSaving(false);
    }
  }

  const almacenNombre = (id: number) => almacenes.find((a: any) => a.idalmacen === id)?.almacen ?? id;

  return (
    <div className="panel">
      <div className="panel-toolbar">
        <h2>Recepciones</h2>
        <button className="btn btn-secondary" onClick={() => exportCsv("recepciones.csv", data)}>
          Exportar CSV
        </button>
      </div>

      {error && <div className="error-box" style={{ margin: 12 }}>{error}</div>}

      <DataGrid
        rows={data}
        loading={loading}
        rowKey={(r: any) => r.idrecepcion}
        onNew={openNew}
        emptyLabel="No hay recepciones registradas"
        columns={[
          { key: "noconsecutivo", label: "No." },
          { key: "fecha", label: "Fecha", render: (r: any) => new Date(r.fecha).toLocaleString() },
          { key: "idalmacen", label: "Almacén", render: (r: any) => almacenNombre(r.idalmacen) },
          { key: "entregadapor", label: "Entregada por" },
          { key: "detalle", label: "Líneas", render: (r: any) => r.detalle?.length ?? 0 },
        ]}
      />

      {showForm && (
        <Modal title="Nueva recepción" onClose={() => setShowForm(false)} wide>
          <form onSubmit={handleSave}>
            {formError && <div className="error-box">{formError}</div>}
            <div className="form-grid">
              <div className="field">
                <label>Almacén</label>
                <select required value={idalmacen} onChange={(e) => setIdalmacen(e.target.value)}>
                  <option value="">Selecciona…</option>
                  {almacenes.map((a: any) => (
                    <option key={a.idalmacen} value={a.idalmacen}>
                      {a.almacen}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Entregada por</label>
                <input value={entregadapor} onChange={(e) => setEntregadapor(e.target.value)} />
              </div>
              <div className="field span-2">
                <label>Nota</label>
                <input value={nota} onChange={(e) => setNota(e.target.value)} />
              </div>
            </div>

            <h4 style={{ margin: "16px 0 8px" }}>Productos</h4>
            {lineas.map((l, i) => (
              <div className="linea-row" key={i}>
                <select value={l.idproducto} onChange={(e) => actualizarLinea(i, "idproducto", e.target.value)}>
                  <option value="">Producto…</option>
                  {productos.map((p: any) => (
                    <option key={p.idproducto} value={p.idproducto}>
                      {p.producto}
                    </option>
                  ))}
                </select>
                <input type="number" min="0" step="0.01" placeholder="Cant." value={l.cantidad} onChange={(e) => actualizarLinea(i, "cantidad", e.target.value)} />
                <input type="number" min="0" step="0.01" placeholder="Costo" value={l.pcosto} onChange={(e) => actualizarLinea(i, "pcosto", e.target.value)} />
                <input type="number" min="0" step="0.01" placeholder="Venta" value={l.pventa} onChange={(e) => actualizarLinea(i, "pventa", e.target.value)} />
                <button type="button" className="btn btn-secondary" onClick={() => setLineas((prev) => prev.filter((_, idx) => idx !== i))}>
                  ✕
                </button>
              </div>
            ))}
            <button type="button" className="btn btn-secondary" onClick={() => setLineas((prev) => [...prev, { ...lineaVacia }])}>
              + Agregar línea
            </button>

            <div className="modal-actions">
              <button type="button" className="btn btn-secondary" onClick={() => setShowForm(false)}>
                Cancelar
              </button>
              <button type="submit" className="btn btn-primary" disabled={saving} style={{ width: "auto" }}>
                {saving ? "Guardando…" : "Guardar"}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
