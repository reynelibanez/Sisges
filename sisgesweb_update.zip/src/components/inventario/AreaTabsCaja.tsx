import { useEffect, useState } from "react";
import { api } from "@/lib/useApi";

interface Linea {
  idproducto: string;
  cantidad: string;
  preciocosto: string;
  pventa: string;
}
interface Pago {
  idmoneda: string;
  tc: string;
  importe: string;
}

const lineaVacia: Linea = { idproducto: "", cantidad: "1", preciocosto: "0", pventa: "0" };
const pagoVacio: Pago = { idmoneda: "", tc: "1", importe: "0" };

interface Carrito {
  lineas: Linea[];
  pagos: Pago[];
  nota: string;
}

function carritoVacio(): Carrito {
  return { lineas: [{ ...lineaVacia }], pagos: [{ ...pagoVacio }], nota: "" };
}

interface Props {
  idalmacen: number;
  areas: any[];
  productos: any[];
  monedas: any[];
  onVentaCreada: () => void;
}

/**
 * Áreas abiertas en simultáneo — reemplaza la modal única "Nueva venta" por
 * el patrón del sistema de escritorio (AreaCaja.cs + Caja.cs): cada área
 * (mesa/salón) tiene su propia pestaña con un pedido en curso, todas
 * abiertas al mismo tiempo, sin perder lo que se lleva cargado en cada una
 * al cambiar de pestaña. Cerrar una pestaña solo la oculta (como el
 * xtraTabControl1_CloseButtonClick original); se puede reabrir con "+".
 */
export default function AreaTabsCaja({ idalmacen, areas, productos, monedas, onVentaCreada }: Props) {
  const [openAreaIds, setOpenAreaIds] = useState<number[]>([]);
  const [activeAreaId, setActiveAreaId] = useState<number | null>(null);
  const [carritos, setCarritos] = useState<Record<number, Carrito>>({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [showReabrir, setShowReabrir] = useState(false);

  // Al cargar las áreas (una sola vez / cuando cambian), abrir todas las
  // pestañas, igual que AreaCaja_Load recorriendo NG_Areas.
  useEffect(() => {
    if (areas.length === 0) return;
    setOpenAreaIds((prev) => (prev.length === 0 ? areas.map((a: any) => a.idarea) : prev));
    setActiveAreaId((prev) => prev ?? areas[0]?.idarea ?? null);
  }, [areas]);

  function carritoDe(idarea: number): Carrito {
    return carritos[idarea] ?? carritoVacio();
  }

  function actualizarCarrito(idarea: number, cambios: Partial<Carrito>) {
    setCarritos((prev) => ({ ...prev, [idarea]: { ...carritoDe(idarea), ...cambios } }));
  }

  function actualizarLinea(idarea: number, i: number, campo: keyof Linea, valor: string) {
    const carrito = carritoDe(idarea);
    const lineas = carrito.lineas.map((l, idx) => (idx === i ? { ...l, [campo]: valor } : l));
    if (campo === "idproducto") {
      const producto = productos.find((p: any) => String(p.idproducto) === valor);
      if (producto) {
        lineas[i].preciocosto = String(producto.pcosto);
        lineas[i].pventa = String(producto.pventa);
      }
    }
    actualizarCarrito(idarea, { lineas });
  }

  function actualizarPago(idarea: number, i: number, campo: keyof Pago, valor: string) {
    const carrito = carritoDe(idarea);
    const pagos = carrito.pagos.map((p, idx) => (idx === i ? { ...p, [campo]: valor } : p));
    actualizarCarrito(idarea, { pagos });
  }

  function cerrarPestana(idarea: number) {
    setOpenAreaIds((prev) => prev.filter((id) => id !== idarea));
    if (activeAreaId === idarea) {
      const restante = openAreaIds.filter((id) => id !== idarea);
      setActiveAreaId(restante[0] ?? null);
    }
  }

  function reabrirPestana(idarea: number) {
    setOpenAreaIds((prev) => (prev.includes(idarea) ? prev : [...prev, idarea]));
    setActiveAreaId(idarea);
    setShowReabrir(false);
  }

  const areasAbiertas = areas.filter((a: any) => openAreaIds.includes(a.idarea));
  const areasCerradas = areas.filter((a: any) => !openAreaIds.includes(a.idarea));
  const activa = areas.find((a: any) => a.idarea === activeAreaId);
  const carrito = activeAreaId ? carritoDe(activeAreaId) : carritoVacio();
  const totalVenta = carrito.lineas.reduce((acc, l) => acc + (Number(l.cantidad) || 0) * (Number(l.pventa) || 0), 0);

  async function handleCobrar(e: React.FormEvent) {
    e.preventDefault();
    if (!activeAreaId) return;
    setSaving(true);
    setFormError(null);
    try {
      await api.post("/api/inventario/ventas", {
        idalmacen,
        nota: carrito.nota,
        detalle: carrito.lineas
          .filter((l) => l.idproducto)
          .map((l) => ({
            idproducto: Number(l.idproducto),
            idarea: activeAreaId,
            cantidad: Number(l.cantidad),
            preciocosto: Number(l.preciocosto),
            pventa: Number(l.pventa),
          })),
        pagos: carrito.pagos
          .filter((p) => p.idmoneda)
          .map((p) => ({
            idmoneda: Number(p.idmoneda),
            tc: Number(p.tc),
            importe: Number(p.importe),
          })),
      });
      // Al cobrar se limpia el pedido de esa área, pero la pestaña queda
      // abierta lista para el próximo pedido (igual que en el sistema de
      // escritorio, donde cada área sigue disponible después de cobrar).
      actualizarCarrito(activeAreaId, carritoVacio());
      onVentaCreada();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "No se pudo cobrar");
    } finally {
      setSaving(false);
    }
  }

  if (areas.length === 0) {
    return (
      <div className="error-box" style={{ margin: 12 }}>
        No hay áreas configuradas. Ve a Áreas y crea al menos una (salón, mesa, barra, etc.).
      </div>
    );
  }

  return (
    <div className="area-caja">
      <div className="area-tabs">
        {areasAbiertas.map((a: any) => (
          <div key={a.idarea} className={`area-tab ${activeAreaId === a.idarea ? "active" : ""}`}>
            <button className="area-tab-label" onClick={() => setActiveAreaId(a.idarea)}>
              {a.area}
              {carritoDe(a.idarea).lineas.some((l) => l.idproducto) && <span className="area-tab-dot" />}
            </button>
            <button
              className="area-tab-close"
              title="Cerrar pestaña"
              onClick={(e) => {
                e.stopPropagation();
                cerrarPestana(a.idarea);
              }}
            >
              ✕
            </button>
          </div>
        ))}
        <div style={{ position: "relative" }}>
          <button
            className="area-tab-add"
            title="Reabrir área"
            onClick={() => setShowReabrir((v) => !v)}
            disabled={areasCerradas.length === 0}
          >
            +
          </button>
          {showReabrir && areasCerradas.length > 0 && (
            <div className="context-menu" style={{ position: "absolute", top: "100%", left: 0 }}>
              {areasCerradas.map((a: any) => (
                <button key={a.idarea} onClick={() => reabrirPestana(a.idarea)}>
                  {a.area}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {activa && (
        <form className="area-tab-body" onSubmit={handleCobrar}>
          {formError && <div className="error-box">{formError}</div>}

          <div className="linea-row" style={{ fontWeight: 700, color: "var(--text-muted)", fontSize: 12 }}>
            <span>Producto</span>
            <span>Cant.</span>
            <span>Precio</span>
            <span></span>
          </div>
          {carrito.lineas.map((l, i) => (
            <div className="linea-row" key={i}>
              <select value={l.idproducto} onChange={(e) => actualizarLinea(activeAreaId!, i, "idproducto", e.target.value)}>
                <option value="">Producto…</option>
                {productos.map((p: any) => (
                  <option key={p.idproducto} value={p.idproducto}>
                    {p.producto}
                  </option>
                ))}
              </select>
              <input
                type="number"
                min="0"
                step="0.01"
                placeholder="Cant."
                value={l.cantidad}
                onChange={(e) => actualizarLinea(activeAreaId!, i, "cantidad", e.target.value)}
              />
              <input
                type="number"
                min="0"
                step="0.01"
                placeholder="Precio"
                value={l.pventa}
                onChange={(e) => actualizarLinea(activeAreaId!, i, "pventa", e.target.value)}
              />
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => actualizarCarrito(activeAreaId!, { lineas: carrito.lineas.filter((_, idx) => idx !== i) })}
              >
                ✕
              </button>
            </div>
          ))}
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => actualizarCarrito(activeAreaId!, { lineas: [...carrito.lineas, { ...lineaVacia }] })}
          >
            + Agregar línea
          </button>
          <div className="total-line">Total: {totalVenta.toFixed(2)}</div>

          <h4 style={{ margin: "12px 0 8px" }}>Pago</h4>
          {carrito.pagos.map((p, i) => (
            <div className="linea-row" key={i} style={{ gridTemplateColumns: "1fr 1fr 1fr auto" }}>
              <select value={p.idmoneda} onChange={(e) => actualizarPago(activeAreaId!, i, "idmoneda", e.target.value)}>
                <option value="">Moneda…</option>
                {monedas.map((m: any) => (
                  <option key={m.idmoneda} value={m.idmoneda}>
                    {m.moneda}
                  </option>
                ))}
              </select>
              <input
                type="number"
                min="0"
                step="0.0001"
                placeholder="Tasa cambio"
                value={p.tc}
                onChange={(e) => actualizarPago(activeAreaId!, i, "tc", e.target.value)}
              />
              <input
                type="number"
                min="0"
                step="0.01"
                placeholder="Importe"
                value={p.importe}
                onChange={(e) => actualizarPago(activeAreaId!, i, "importe", e.target.value)}
              />
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => actualizarCarrito(activeAreaId!, { pagos: carrito.pagos.filter((_, idx) => idx !== i) })}
              >
                ✕
              </button>
            </div>
          ))}
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => actualizarCarrito(activeAreaId!, { pagos: [...carrito.pagos, { ...pagoVacio }] })}
          >
            + Agregar forma de pago
          </button>

          <div className="field" style={{ marginTop: 12 }}>
            <label>Nota</label>
            <input value={carrito.nota} onChange={(e) => actualizarCarrito(activeAreaId!, { nota: e.target.value })} />
          </div>

          <div className="modal-actions" style={{ marginTop: 12 }}>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => actualizarCarrito(activeAreaId!, carritoVacio())}
            >
              Vaciar pedido
            </button>
            <button type="submit" className="btn btn-primary" disabled={saving} style={{ width: "auto" }}>
              {saving ? "Cobrando…" : `Cobrar — ${activa.area}`}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
