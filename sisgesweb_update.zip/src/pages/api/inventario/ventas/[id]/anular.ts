import type { APIRoute } from "astro";
import { and, eq } from "drizzle-orm";
import { db } from "@/db/client";
import { ilValesSalida, ilValesSalidaDetalle } from "@/db/schema";
import { json, requireUser, isResponse } from "@/lib/api";
import { ajustarExistencia } from "@/lib/existencias";

export const prerender = false;

export const POST: APIRoute = async ({ params, locals }) => {
  const user = requireUser(locals, "caja");
  if (isResponse(user)) return user;

  const id = Number(params.id);

  const result = await db.transaction(async (tx) => {
    const [venta] = await tx
      .select()
      .from(ilValesSalida)
      .where(and(eq(ilValesSalida.idvalesalida, id), eq(ilValesSalida.idempresa, user.idempresa)))
      .limit(1);

    if (!venta) return null;
    if (venta.anulada) return venta;

    const lineas = await tx
      .select()
      .from(ilValesSalidaDetalle)
      .where(eq(ilValesSalidaDetalle.idvalesalida, id));

    for (const linea of lineas) {
      // Devuelve al almacén lo que la venta había sacado.
      await ajustarExistencia(tx, {
        idempresa: user.idempresa,
        idalmacen: venta.idalmacen,
        idproducto: linea.idproducto,
        delta: Number(linea.cantidad),
      });
    }

    const [actualizada] = await tx
      .update(ilValesSalida)
      .set({ anulada: true })
      .where(eq(ilValesSalida.idvalesalida, id))
      .returning();

    return actualizada;
  });

  if (!result) return json({ error: "No encontrado" }, 404);
  return json(result);
};
