import type { APIRoute } from "astro";
import { eq } from "drizzle-orm";
import { db } from "@/db/client";
import { ilExistencias, ngProductos, ngAlmacen } from "@/db/schema";
import { json, requireUser, isResponse } from "@/lib/api";

export const prerender = false;

export const GET: APIRoute = async ({ locals }) => {
  const user = requireUser(locals, "inventario");
  if (isResponse(user)) return user;

  const rows = await db
    .select({
      idexistencia: ilExistencias.idexistencia,
      idalmacen: ilExistencias.idalmacen,
      almacen: ngAlmacen.almacen,
      idproducto: ilExistencias.idproducto,
      producto: ngProductos.producto,
      referencia: ngProductos.referencia,
      saldo: ilExistencias.saldo,
    })
    .from(ilExistencias)
    .innerJoin(ngProductos, eq(ngProductos.idproducto, ilExistencias.idproducto))
    .innerJoin(ngAlmacen, eq(ngAlmacen.idalmacen, ilExistencias.idalmacen))
    .where(eq(ilExistencias.idempresa, user.idempresa));

  return json(rows);
};
