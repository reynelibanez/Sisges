import type { SessionPayload } from "./auth";

export function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

/** El middleware ya bloquea rutas /api/* sin sesión, esto es solo para
 * tener el tipo no-nulo a mano y chequear el permiso de módulo puntual. */
export function requireUser(
  locals: App.Locals,
  modulo?: keyof SessionPayload["permisos"]
): SessionPayload | Response {
  const user = locals.user;
  if (!user) return json({ error: "No autorizado" }, 401);
  if (modulo && !user.permisos[modulo] && !user.administrador) {
    return json({ error: `No tienes permiso de ${modulo}` }, 403);
  }
  return user;
}

export function isResponse(x: unknown): x is Response {
  return x instanceof Response;
}
